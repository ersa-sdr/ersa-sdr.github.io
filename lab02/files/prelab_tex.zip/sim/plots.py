import json, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':0.3,'figure.dpi':150})
S=json.load(open('sweeps.json')); T=json.load(open('table.json')); out='/home/claude/pre2/figs/'
# 1 compression
fig,ax=plt.subplots(1,2,figsize=(9,3.4))
for a,g in zip(ax,(0,40)):
    d=S[f'p1db_{g}']; ps=np.array(d['ps']); o=np.array(d['out'])
    a.plot(ps,o,'o-',ms=3,label='measured tone (dBFS)'); a.plot(ps,ps+d['g0'],'--',label='linear (small-signal)')
    a.axvline(d['p1'],color='C3',lw=1); a.text(d['p1'],o.min(),f"  P1dB = {d['p1']:.1f} dBm",color='C3')
    a.set_title(f'Gain {g} dB'); a.set_xlabel('Input tone power (dBm)'); a.set_ylabel('Output (dBFS)'); a.legend(fontsize=8,loc='upper left')
fig.tight_layout(); fig.savefig(out+'compression.png')
# 2 two-tone
fig,ax=plt.subplots(1,2,figsize=(9,3.6))
for a,g in zip(ax,(0,40)):
    r=np.array(S[f'tt_{g}']); p=r[:,0]; t=r[:,1]; im=np.maximum(r[:,3],r[:,4])
    a.plot(p,t,'o-',ms=3,label='tone f1'); a.plot(p,im,'s-',ms=3,label='IM3 (max of 2f1-f2, 2f2-f1)')
    if g==0:
        G=30.0; iip3=-25.3; x=np.linspace(-60,-20,10)
        a.plot(x,x+G,':',color='C0'); a.plot(x,3*x-2*iip3+G,':',color='C1')
        a.plot(iip3,iip3+G,'k*',ms=9); a.text(iip3-14,iip3+G+2,'IIP3 = -25.3 dBm')
        a.set_ylim(-75,10)
    a.set_title(f'Two-tone test, gain {g} dB'); a.set_xlabel('Input power per tone (dBm)'); a.set_ylabel('Output (dBFS)'); a.legend(fontsize=8,loc='upper left')
fig.tight_layout(); fig.savefig(out+'twotone.png')
# 3 gain table
g=[r['g'] for r in T]; fig,a=plt.subplots(figsize=(6.5,3.4)); b=a.twinx()
a.plot(g,[r['NF'] for r in T],'o-',label='NF (dB)'); b.plot(g,[r['DR'] for r in T],'s-',color='C2',label='P1dB - floor(10 kHz) (dB)')
a.set_xlabel('Receiver gain (dB)'); a.set_ylabel('Noise figure (dB)'); b.set_ylabel('P1dB - noise floor (dB)')
h1,l1=a.get_legend_handles_labels(); h2,l2=b.get_legend_handles_labels(); a.legend(h1+h2,l1+l2,fontsize=8,loc='lower left')
fig.tight_layout(); fig.savefig(out+'gain_tradeoff.png')
# 4 antenna
import importlib.util; spec=importlib.util.spec_from_file_location('ant','ant.py')
src=open('ant.py').read().split("print('ntaps'")[0]; ns={}; exec(src,ns)
fr=np.arange(400e6,3000e6+1,1e6); r=np.array([ns['resp'](x) for x in fr])
fig,a=plt.subplots(figsize=(6.5,3.2)); a.plot(fr/1e6,r); a.set_ylim(-80,5); a.axhline(-3,color='C3',ls='--',lw=1)
for x in (808.5,1791.5): a.axvline(x,color='C3',lw=1)
a.text(830,-12,'fL = 808.5 MHz'); a.text(1500,-12,'fH = 1791.5 MHz')
a.set_xlabel('RF-equivalent frequency (MHz)'); a.set_ylabel('Response (dB)'); a.set_title('Simulated antenna/filter response (400-3000 MHz)')
fig.tight_layout(); fig.savefig(out+'antenna.png')
print('ok')
