"""Numpy re-implementation of the instructor's lab02_sim receiver model (lab02_sim.py):
input = tone1 + tone2 + thermal noise -> front end y = x(1 - |x|^2/IIP3_lin)
-> gain 10^((G - Pfs0)/20) -> + ADC noise -> clip +-1 per I/Q -> 8-bit round -> measurements."""
import numpy as np
FS=2.048e6; PFS0=-30.0; NF_FE=6.0; IIP3_FE=-25.0
KT0_FS=10**((-173.98+10*np.log10(FS))/10)
F1,F2=300e3,400e3; BW_TONE=10e3; F_NOISE=-500e3; BW_NOISE=400e3
rng=np.random.default_rng(1)
def cgauss(p,n): return np.sqrt(p/2)*(rng.standard_normal(n)+1j*rng.standard_normal(n))
def run(gain, mode, p_in=-80, enr_db=15, n=2**20):
    t=np.arange(n)/FS
    a=np.sqrt(10**(p_in/10))
    x=cgauss(KT0_FS*(1+(mode==1)*10**(enr_db/10))+KT0_FS*(10**(NF_FE/10)-1),n)
    if mode>=2: x=x+a*np.exp(2j*np.pi*F1*t)
    if mode==3: x=x+a*np.exp(2j*np.pi*F2*t)
    y=x*(1-np.abs(x)**2/10**(IIP3_FE/10))
    y=y*10**((gain-PFS0)/20)+cgauss(2*(0.5/127)**2,n)
    i=np.rint(np.clip(y.real,-1,1)*127)/127; q=np.rint(np.clip(y.imag,-1,1)*127)/127
    z=i+1j*q
    Z=np.fft.fft(z)/n; f=np.fft.fftfreq(n,1/FS); P=np.abs(Z)**2
    band=lambda fc,bw: 10*np.log10(P[np.abs(f-fc)<=bw/2].sum())
    return dict(t1=band(F1,BW_TONE),t2=band(F2,BW_TONE),im_lo=band(2*F1-F2,BW_TONE),im_hi=band(2*F2-F1,BW_TONE),noise=band(F_NOISE,BW_NOISE))
