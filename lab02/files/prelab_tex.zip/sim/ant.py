import numpy as np
fs=2e6; fc=250e3; tw=25e3
# GNU Radio firdes.low_pass with default Hamming window
ntaps=int(53*fs/(22*tw)); ntaps|=1
M=(ntaps-1)/2; n=np.arange(ntaps)-M
w=0.54-0.46*np.cos(2*np.pi*np.arange(ntaps)/(ntaps-1))
fwT0=2*np.pi*fc/fs
h=np.where(n==0, fwT0/np.pi, np.sin(n*fwT0)/(np.pi*np.where(n==0,1,n)))*w
h/=h.sum()
def resp(frf):
    f=(frf-1300e6)/2000
    H=np.sum(h*np.exp(-2j*np.pi*f/fs*np.arange(ntaps)))
    return 20*np.log10(abs(H)+1e-12)
print('ntaps',ntaps)
fr=np.arange(400e6,3000e6+1,0.1e6); r=np.array([resp(x) for x in fr])
pk=r.max(); print('peak dB',round(pk,4),'at',fr[r.argmax()]/1e6)
ab=fr[r>=pk-3]; print('fL,fH (0.1MHz grid)',ab.min()/1e6,ab.max()/1e6,'BW',(ab.max()-ab.min())/1e6)
g=np.arange(400e6,3000e6+1,20e6); rg=np.array([resp(x) for x in g])
for x,y in zip(g,rg):
    if 700e6<=x<=900e6 or 1700e6<=x<=1900e6: print(int(x/1e6),round(y,2))
