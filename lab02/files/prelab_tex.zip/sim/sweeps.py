from rxsim import *
import json


def p1db(g, lo, hi, step=1.0, n=2**17):
    """Single-tone sweep; returns input levels, output dBFS, small-signal gain and interpolated input P1dB."""
    ps = np.arange(lo, hi + 0.01, step)
    out = np.array([run(g, 2, p, n=n)['t1'] for p in ps])
    G = out - ps
    g0 = np.median(G[:5])
    comp = g0 - G
    k = np.argmax(comp >= 1.0)
    p = ps[k - 1] + (1 - comp[k - 1]) / (comp[k] - comp[k - 1]) * step
    return ps, out, g0, p


if __name__ == "__main__":
    res = {}
    for g in (40, 0):
        lo, hi = (-100, -60) if g == 40 else (-65, -25)
        ps, out, g0, p = p1db(g, lo, hi)
        res[f"p1db_{g}"] = dict(ps=ps.tolist(), out=out.tolist(), g0=g0, p1=p)
        print(f"gain {g}: small-signal gain {g0:.2f}, P1dB_in {p:.2f} dBm")
    for g, levels in ((0, np.arange(-60, -34, 2)), (40, np.arange(-100, -66, 2))):
        rows = []
        for p in levels:
            r = run(g, 3, p, n=2**18)
            rows.append((float(p), r['t1'], r['t2'], r['im_lo'], r['im_hi']))
        res[f"tt_{g}"] = rows
    json.dump(res, open('sweeps.json', 'w'), default=float)
