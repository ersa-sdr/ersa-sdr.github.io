from rxsim import *
import json
from sweeps import p1db
rows=[]
for g in range(0,51,10):
    enr=15 if g>=30 else (35 if g>=10 else 45)
    off=run(g,0,enr_db=enr,n=2**20)['noise']; on=run(g,1,enr_db=enr,n=2**20)['noise']
    Y=on-off; NF=10*np.log10(10**(enr/10)/(10**(Y/10)-1))
    lo=-30-g-35; hi=min(-25,-30-g+8)
    _,_,g0,p=p1db(g,lo,hi,step=1.0,n=2**16)
    nf10=-174+NF+40
    rows.append(dict(g=g,enr=enr,Y=Y,NF=NF,P1=p,floor=nf10,DR=p-nf10))
    print(f"G {g:2d}  ENR {enr}  Y {Y:5.2f}  NF {NF:5.2f}  P1dB {p:6.2f}  floor10k {nf10:7.2f}  P1dB-floor {p-nf10:6.2f}")
json.dump(rows,open('table.json','w'))
